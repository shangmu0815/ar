#!/bin/bash

#############################
# Define functions
#############################
change_folder_mod() {
    adb shell chmod 777 /data/ota_package/
}

get_version() {
    VER=$(adb shell getprop ro.build.display.id)
    echo "$VER"
}

get_upgrade_cmd() {
    echo "$(echo -e ${swAndUpgCmdMap["$1"]})"
}

get_upgrade_img() {
    echo "${swAndUpgImgMap["$1"]}"
}

get_target_ver() {
    for i in "${!swImgMap[@]}"; do
        if [ "${swImgMap[$i]}" = "$1" ]; then
            ((i=i+1))
            if [ $i -eq ${#swImgMap[*]} ]; then
                echo "${swImgMap[0]}"
                break
            else
                echo "${swImgMap[$i]}"
                break
            fi
        fi
    done
}

#############################
# Main
#############################
adb wait-for-device

if [ -d log ]; then
    mkdir -p "log"
fi
logGroup=$(date +%Y%m%d%H%M)
mkdir -p  ./log/"$logGroup"
echo "============================"
echo "LOG PATH for this stress run:" $logGroup
echo "============================"

# declare map for mapping sw map upgrade image zip name 
# and sw map upgrade command
declare -A swAndUpgImgMap
declare -A swAndUpgCmdMap
declare -A swImgMap

imageFolder="images"

# load data from csv file and ignore first line
index=0
while IFS="," read -r rec_col1 rec_col2 rec_col3;
do
    # skip header in csv
    if [ $index != 0 ]; then
        swAndUpgImgMap["$rec_col1"]="$rec_col2"
        swAndUpgCmdMap["$rec_col1"]="$rec_col3"
        swImgMap[$(($index-1))]="$rec_col1"
    fi
    index=$(($index+1))
done < "$imageFolder/fota_config.csv"

count=0
while [ "$count" -ne 10000000 ]
do
    # wait for device boot complete
    bootup=`adb shell 'getprop' | grep "sys.boot_completed"`
    if [ "$bootup" == "[sys.boot_completed]: [1]" ]; then
        ((count=count+1))
        echo "Start round $count"
        echo "----------------"

        # logging
        logFolder=$(date +%Y%m%d%H%M%S)
        mkdir -p  ./log/$logGroup/"$logFolder"
        echo "log folder:" $logFolder
        adb logcat -v threadtime -b main -b system -b kernel > log/$logGroup/$logFolder/logcat.log &
        log_pid=$!

        # get version
        unset dev_ver
        dev_ver=$(get_version)
        echo "Software Version:" $dev_ver

        # get expect upgrade img zip name ex:upg_image:700to718.zip
        unset upg_image
        upg_image=$(get_upgrade_img "$dev_ver")
        echo "Upgrade Available: $upg_image"

        upgExpectVer=$(get_target_ver "$dev_ver")

        # get upgrade command
        unset upg_cmd
        upg_cmd=$(get_upgrade_cmd "$dev_ver")
        #echo "$upg_cmd"

        if [ "$upg_cmd" == "" ] || [ "$upgExpectVer" == "" ] || [ "$upg_image" == "" ] || [ ! -f "$imageFolder/$upg_image" ]; then
            echo "Error, no mapping upgrade info found!!"
            break
        fi

        adb push $imageFolder/$upg_image /data/ota_package/update.zip
        change_folder_mod

        # execute upgrade command and reboot dev to check expect version
        echo "execute upgrade command"
        unset result
        result=$(adb shell "$upg_cmd" 2>&1)
        if [[  $result =~ "kSuccess" ]]; then
            echo "update engine perform success!"
            echo "rebooting..."
            adb reboot
            adb wait-for-device
            echo "device found,check now and expect version"
            now_ver=$(get_version)
            echo "Target Software Version: $upgExpectVer"
            echo "Software Version after upgrade: $now_ver"
            if [ "$now_ver" == "$upgExpectVer" ]; then
                echo "UPGRADE SUCCESS!!!"
                echo ""
            else
                echo "UPGRADE FAILED!!!"
                echo ""
                break
            fi
            #unset variables
            unset result
            unset now_ver
            unset dev_ver
        else
            echo "$result"
            echo "ERROR detected!!! STOP stress test!!!"
            break
        fi
    else
        sleep 5
    fi
done

echo "dump additional log, please wait..."
kill -9 $log_pid
adb bugreport log/$logGroup/$logFolder/
adb shell dumpsys > log/$logGroup/$logFolder/dumpsys.txt 2>/dev/null
echo "Upgrade Stress Test Failed!!!"
